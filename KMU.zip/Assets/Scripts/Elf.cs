using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elf : Card
{
    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
